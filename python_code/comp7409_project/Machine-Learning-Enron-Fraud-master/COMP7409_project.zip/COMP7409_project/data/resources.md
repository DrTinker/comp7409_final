### Resources Used

* [Machine Learning Mastery Blog](http://machinelearningmastery.com/how-to-identify-outliers-in-your-data/)

* Sklearn Documentation

* Python Documentation

* Udacity Forums

* [Allen Breyes GitHub](https://github.com/allanbreyes/udacity-data-science) 

* Stack Overflow

  
